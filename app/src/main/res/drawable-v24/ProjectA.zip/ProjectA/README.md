# AADProject
Associate Android Developers project

https://github.com/Olayanju-1234/AADProject/blob/master/Screenshot_20200910-210407_ProjectA.jpg
https://github.com/Olayanju-1234/AADProject/blob/master/Screenshot_20200910-210413_ProjectA.jpg
https://github.com/Olayanju-1234/AADProject/blob/master/Screenshot_20200910-210418_ProjectA.jpg
https://github.com/Olayanju-1234/AADProject/blob/master/Screenshot_20200910-210429_ProjectA.jpg
https://github.com/Olayanju-1234/AADProject/blob/master/Screenshot_20200910-212002_ProjectA.jpg
